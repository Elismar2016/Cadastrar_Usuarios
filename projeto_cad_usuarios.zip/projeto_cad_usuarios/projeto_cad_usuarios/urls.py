

from django.urls import path
from app_cad_usuarios import views

urlpatterns = [
 #rota, view responsavel, nome de referencia
 #cerberus.sejusp.ac.gov.br/home (controller)
 path('', views.home, name='home'),
  #cerberus.sejusp.ac.gov.br/usuarios (controller descrito no views.py)
 path('usuarios/',views.usuario,name='listagem_usuarios')
]
