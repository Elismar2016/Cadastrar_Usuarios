

from django.urls import path
from app_cad_usuarios import views

urlpatterns = [
 
  #cerberus.sejusp.ac.gov.br/usuarios (controller descrito no views.py)
 
]

